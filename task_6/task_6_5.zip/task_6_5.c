#include <stdio.h>
#include <stdlib.h>


int factor(int num){
	if (num < 1) return -1;
	else if (num == 1) return 1;
	else return num * factor(num - 1);

}

void task(){
	printf("Enter num1 for count factorial\n");
	int num = 0;
	scanf("%d", &num);
	int result = factor(num);
	if (result != -1) printf("result of %d! = %d\n", num, result);
	else {
		printf("Error in counting factorial foo\n");
	}

	printf("Enter num2 for count factorial\n");
	scanf("%d", &num);
	result = factor(num);
        if (result != -1) printf("result of %d! = %d\n", num, result);
        else {
                printf("Error in counting factorial foo\n");
        }
	return;	
}
	
int main(){
	task();
	return 0;
}
